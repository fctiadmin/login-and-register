<?php
session_start();
$dbcon=mysqli_connect("localhost","root","","student_info");
if(isset($_POST['submit'])){
$username=$_POST['username'];
$password=$_POST['password'];
$input_error=array();
if(empty($username)){
   $input_error['username']="error";
}
if(empty($password)){
   $input_error['password']="error";
}
$username_check=mysqli_query($dbcon,"SELECT * FROM `register` WHERE `username`='$username'");
if(mysqli_num_rows($username_check)==1){
$rows=mysqli_fetch_assoc($username_check);
if($rows['password']==md5($password)){
if($rows['status']=='Active'){
   $_SESSION['username']=$username;
header('Location:dashboard.php');
}else{
   echo '
   <script>
   alert("Your account inactive.Please at first active your account!");
   window.location.href="login.php";
   </script>
   ';
}

}else{
   echo '
   <script>
   alert("Wrong password!");
   window.location.href="login.php";
   </script>
   ';
}
}else{
   echo '
   <script>
   alert("Username not found!");
   window.location.href="login.php";
   </script>
   ';
}




}

?>



<!DOCTYPE html>
<html lang="en" dir="ltr">
   <head>
      <meta charset="utf-8">
      <title>Login Form</title>
      <link rel="stylesheet" href="css/style.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
   </head>
   <body>
    
         <div class="container">
            <div class="text">
               Login Form
            </div>
            <form action=""  method="POST" enctype="multipart/form-data" >
               <div class="data" >
                  <label>Username</label>
                  <input type="text" class="<?php if(isset($input_error['username'])){echo $input_error['username'];}?>" placeholder="Username" name="username"> 
               </div>
               <div class="data">
                  <label>Password</label>
                  <input type="password" class="<?php if(isset($input_error['password'])){echo $input_error['password'];}?>" placeholder="Password" name="password">
               </div>
               <div class="forgot-pass">
                  <a href="#">Forgot Password?</a>
               </div>
               <div class="btn">
                  <div class="inner"></div>
                  <button type="submit" name="submit">Login</button>
               </div>
               <div class="signup-link">
                  Not a member? <a href="index.php">Signup now</a>
               </div>
            </form>
         </div>

   </body>
</html>