-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 10, 2024 at 12:19 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `student_info`
--

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `id` int(11) NOT NULL,
  `sname` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `password` varchar(200) NOT NULL,
  `status` varchar(20) NOT NULL,
  `reg_time` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `sname`, `username`, `email`, `mobile`, `password`, `status`, `reg_time`) VALUES
(1, 'sarnaly', 'sarna', ' sarna@gmail.com', ' 01234567890', 'a1f925a7b5b70b7b3f7fe2208513e10f', '', '2024-07-07 15:16:41'),
(2, 'sharmin', 'sharmin123', ' sharmin@gmail.com', ' 01234567890', 'a1f925a7b5b70b7b3f7fe2208513e10f', '', '2024-07-09 15:07:21'),
(3, 'sarnaly', 'sarna', 'sarna@gmail.com', '01234567890', '25f9e794323b453885f5181f1b624d0b', '', '2024-07-12 15:20:20'),
(4, 'sarnaly', 'sarna', 'sarnaiy@gmail.com', '01234567890', '25f9e794323b453885f5181f1b624d0b', '', '2024-07-12 15:21:28'),
(6, 'sarnaly', 'sarnaly123', 'sarnaly@gmail.com', '01234567890', '25f9e794323b453885f5181f1b624d0b', '', '2024-07-14 15:29:21'),
(7, 'sumiya', 'sumiya123', 'sumiya@gmail.com\r\n', '0123654789', '8b4cf0258846b23e0a8272bee22c38dd', '', '2024-07-28 15:12:51'),
(8, 'sadiya', 'sadiya123', 'sadiya@gmail.com', '01234567890', '25f9e794323b453885f5181f1b624d0b', '', '2024-07-30 15:48:22'),
(9, 'kakoli', 'kakoliislam', 'kakoli@gmail.com', '01954496280', '25f9e794323b453885f5181f1b624d0b', '', '2024-08-10 15:21:49'),
(10, 'Md Zahid Hossain', 'adminzahid', 'zahidcomputer@gmail.com', '01928248173', '25f9e794323b453885f5181f1b624d0b', 'Active', '2024-08-10 15:41:03');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
